# Double-Tap to Like — Implementation Spec

Nov 17, 2026 · @Ihsan Husandi

## Overview

Double-tap to like is a Rive animation overlay on the post widget of the Tailtopia Flutter app. Double-tapping a post likes it and plays a ripple-and-heart animation that ends on the post's like button.

All visuals live in one Rive file. The app detects the taps, passes positions into the animation, and reacts when the heart lands.

## Behavior

The full sequence takes under 1 second, from the second tap to the heart landing.

1. **First tap:** nothing visible.
2. **Second tap within 300 ms and 40 px of the first:** a double tap is detected and the like is saved. Gap = time between the two taps, clamped to 120–300 ms.
3. **Ripple 1:** a soft circle expands and fades at the tap point. Its duration equals the gap, so it follows the user's tap rhythm.
4. **Ripple 2 and heart:** when ripple 1 ends, a second ripple plays and a heart pops from its center, floats up, then dashes into the like button and fades.
5. **Landing:** the like button bumps (scale 1 → 1.3 → 1, about 200 ms).

Rules:

- A double tap only likes, never unlikes. If the post is already liked, the animation still plays.
- If the like button is off-screen, the animation is skipped and the post is liked directly.
- If the system reduce-motion setting is on, the animation is skipped; the post is liked and the button bumps.
- Rapid repeated double taps restart the animation cleanly.

## Rive file reference

### Assets

| File | Purpose |
| --- | --- |
| Like.riv (2.9 KB) | Runtime file loaded by the app |
| Like.rev | Rive Editor source backup; import it into Rive to view or edit the animation |

Changes to the animation are made in the Rive Editor, then Like.riv is re-exported and replaced in the app.

### Contract

Artboard **LikeOverlay** (transparent, the only artboard), state machine **Like**, view model **Like**.

| Name | Type | Direction | Purpose |
| --- | --- | --- | --- |
| tapX, tapY | Number (logical px) | App → Rive | Second tap position, relative to the overlay |
| targetX, targetY | Number (logical px) | App → Rive | Like button center, relative to the overlay |
| ripple1Progress | Number 0–1, default 1 | App → Rive | Drives ripple 1; 1 = hidden. The app animates it 0 → 1 |
| burst | Trigger | App → Rive | Starts ripple 2 and the heart |
| landed | Rive Event | Rive → App | The heart reached the like button |

At rest everything is invisible, so the overlay can stay on top of the post permanently.

### Timing after burst

| Time | What happens |
| --- | --- |
| 0 ms | Ripple 2 starts; the heart pops from the tap point with a slight overshoot |
| \~0–300 ms | Heart rises about 60 px with a gentle sway |
| \~300–530 ms | Heart dashes to the like button (fast ease-in-out) and shrinks to about half size |
| \~533 ms | Heart fades out; landed fires |

## Implementation

Two routes reach the same result: generating it with Claude Code, or manual implementation with the code below. The code targets `rive` 0.14.x; method names may differ slightly in other versions.

### Requirements

- `rive` Flutter package 0.14.x or newer, with support for data binding, data converters, vector feathering and Rive Events. Older versions may load the file but draw hard edges or skip ripple 1.
- The overlay must cover the whole post (media and action bar) so the heart can reach the like button.

### With Claude Code

Run inside the Flutter project. It produces the same structure as the manual implementation below.

```
Integrate a Rive "double tap to like" overlay on the post widget.

Asset: assets/rive/like.riv (register it in pubspec.yaml if it isn't already).
First check the installed `rive` package version supports data binding, DataConverterRangeMapper,
vector feathering and Rive Events. If not, upgrade to the latest stable and report what changed.

Rive contract: artboard "LikeOverlay", state machine "Like", view model "Like"
- numbers: tapX, tapY, targetX, targetY (logical px, relative to the overlay), ripple1Progress (0–1, default 1 = hidden)
- trigger: burst (ripple 2 + heart flight)
- Rive Event: landed (heart reached the target, ~533ms after burst)

Behavior:
1. Overlay a RiveWidget on the whole post with Fit.layout (layoutScaleFactor 1), wrapped in IgnorePointer.
2. Detect double taps on the post media with a Listener (onPointerDown, use event.timeStamp):
   second tap within 300ms and 40px. First tap shows nothing. gap = time between taps, clamped to 120–300ms.
3. On double tap: save the like immediately (never unlike). Set tapX/tapY to the second tap position;
   targetX/targetY to the like button's center (GlobalKey → localToGlobal → overlay coordinates).
   Set ripple1Progress = 0, animate to 1 over `gap` ms with Curves.easeOut, then fire burst.
4. On landed: bump the like button 1→1.3→1 (~200ms).
5. Like button off-screen: no animation, like only.
6. MediaQuery.disableAnimations: no animation, like + bump.
7. Rapid repeated double taps restart cleanly; dispose controllers properly.
Put it in a reusable widget (e.g. DoubleTapLikeOverlay) without restructuring the post widget.
```

### Manual implementation

1. **Add the dependency and asset** in `pubspec.yaml`, then run `flutter pub get`.

```yaml
dependencies:
  rive: ^0.14.11

flutter:
  assets:
    - assets/rive/like.riv
```

2. **Initialize Rive** once at app start in `main.dart`.

```dart
import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await RiveNative.init();
  runApp(const TailtopiaApp());
}
```

3. **Add the overlay widget** as `lib/widgets/double_tap_like_overlay.dart`. It detects the double tap, measures the gap, drives ripple 1, fires `burst` and reports `landed`.

```dart
import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

/// Wraps a post and plays the Rive double-tap-to-like animation over it.
class DoubleTapLikeOverlay extends StatefulWidget {
  const DoubleTapLikeOverlay({
    super.key,
    required this.child,
    required this.mediaKey,
    required this.likeButtonKey,
    required this.onLike,
    this.onLanded,
  });

  /// The whole post: media and action bar.
  final Widget child;

  /// Key on the post media. Only taps inside it count.
  final GlobalKey mediaKey;

  /// Key on the like button. The heart flies to its center.
  final GlobalKey likeButtonKey;

  /// Saves the like. Must only like, never unlike.
  final VoidCallback onLike;

  /// The heart reached the like button. Use it to bump the button.
  final VoidCallback? onLanded;

  @override
  State<DoubleTapLikeOverlay> createState() => _DoubleTapLikeOverlayState();
}

class _DoubleTapLikeOverlayState extends State<DoubleTapLikeOverlay>
    with SingleTickerProviderStateMixin {
  static const _maxGap = Duration(milliseconds: 300);
  static const _maxDistance = 40.0;

  final _overlayKey = GlobalKey();
  late final AnimationController _ripple1 =
      AnimationController(vsync: this)..addListener(_onRipple1Tick);

  File? _file;
  RiveWidgetController? _controller;
  ViewModelInstance? _vm;
  ViewModelInstanceNumber? _tapX, _tapY, _targetX, _targetY, _ripple1Progress;
  ViewModelInstanceTrigger? _burst;

  Duration? _lastTapTime;
  Offset? _lastTapPos;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final file =
        await File.asset('assets/rive/like.riv', riveFactory: Factory.rive);
    if (file == null) return;
    if (!mounted) {
      file.dispose();
      return;
    }
    final controller = RiveWidgetController(
      file,
      artboardSelector: ArtboardSelector.byName('LikeOverlay'),
      stateMachineSelector: StateMachineSelector.byName('Like'),
    );
    final vm = controller.dataBind(DataBind.auto());
    controller.stateMachine.addEventListener(_onRiveEvent);
    setState(() {
      _file = file;
      _controller = controller;
      _vm = vm;
      _tapX = vm.number('tapX');
      _tapY = vm.number('tapY');
      _targetX = vm.number('targetX');
      _targetY = vm.number('targetY');
      _ripple1Progress = vm.number('ripple1Progress');
      _burst = vm.trigger('burst');
    });
  }

  void _onRipple1Tick() {
    _ripple1Progress?.value = Curves.easeOut.transform(_ripple1.value);
  }

  void _onPointerDown(PointerDownEvent event) {
    if (!_contains(widget.mediaKey, event.position)) return;
    final last = _lastTapTime;
    final lastPos = _lastTapPos;
    final isDoubleTap = last != null &&
        lastPos != null &&
        event.timeStamp - last <= _maxGap &&
        (event.localPosition - lastPos).distance <= _maxDistance;

    if (!isDoubleTap) {
      _lastTapTime = event.timeStamp;
      _lastTapPos = event.localPosition;
      return;
    }
    final gapMs = (event.timeStamp - last).inMilliseconds.clamp(120, 300);
    _lastTapTime = null;
    _lastTapPos = null;
    _playLike(event.localPosition, Duration(milliseconds: gapMs));
  }

  Future<void> _playLike(Offset tap, Duration gap) async {
    widget.onLike();

    final target = _likeButtonCenter();
    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    if (target == null) return; // like button off-screen: like only
    if (reduceMotion || _controller == null) {
      widget.onLanded?.call(); // no animation: just bump the button
      return;
    }

    _tapX?.value = tap.dx;
    _tapY?.value = tap.dy;
    _targetX?.value = target.dx;
    _targetY?.value = target.dy;

    _ripple1.duration = gap;
    try {
      await _ripple1.forward(from: 0).orCancel;
    } on TickerCanceled {
      return; // a newer double tap restarted the animation
    }
    if (mounted) _burst?.trigger();
  }

  void _onRiveEvent(Event event) {
    if (event case GeneralEvent(name: 'landed')) {
      widget.onLanded?.call();
    }
  }

  /// Like button center in overlay coordinates, or null when off-screen.
  Offset? _likeButtonCenter() {
    final button =
        widget.likeButtonKey.currentContext?.findRenderObject() as RenderBox?;
    final overlay =
        _overlayKey.currentContext?.findRenderObject() as RenderBox?;
    if (button == null || overlay == null || !button.hasSize) return null;
    final global = button.localToGlobal(button.size.center(Offset.zero));
    final screen = Offset.zero & MediaQuery.sizeOf(context);
    if (!screen.contains(global)) return null;
    return overlay.globalToLocal(global);
  }

  bool _contains(GlobalKey key, Offset globalPosition) {
    final box = key.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return false;
    return box.size.contains(box.globalToLocal(globalPosition));
  }

  @override
  void dispose() {
    _ripple1.dispose();
    _controller?.stateMachine.removeEventListener(_onRiveEvent);
    for (final p in [_tapX, _tapY, _targetX, _targetY, _ripple1Progress]) {
      p?.dispose();
    }
    _burst?.dispose();
    _vm?.dispose();
    _controller?.dispose();
    _file?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onPointerDown,
      child: Stack(
        key: _overlayKey,
        children: [
          widget.child,
          if (controller != null)
            Positioned.fill(
              child: IgnorePointer(
                child: RiveWidget(
                  controller: controller,
                  fit: Fit.layout,
                  layoutScaleFactor: 1,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
```

4. **Wrap the post** with the overlay. Put `mediaKey` on the post media and `likeButtonKey` on the like button, and bump the button on `onLanded`. Names like `post.isLiked` and `widget.onLikeChanged` stand in for the app's own post model and state.

```dart
class _PostCardState extends State<PostCard>
    with SingleTickerProviderStateMixin {
  final _mediaKey = GlobalKey();
  final _likeKey = GlobalKey();

  late final AnimationController _bump = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 200),
  );
  late final Animation<double> _bumpScale = TweenSequence([
    TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.3), weight: 50),
    TweenSequenceItem(tween: Tween(begin: 1.3, end: 1.0), weight: 50),
  ]).animate(CurvedAnimation(parent: _bump, curve: Curves.easeOut));

  void _likeFromDoubleTap() {
    if (!widget.post.isLiked) widget.onLikeChanged(true); // never unlike
  }

  @override
  void dispose() {
    _bump.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final liked = widget.post.isLiked;
    return DoubleTapLikeOverlay(
      mediaKey: _mediaKey,
      likeButtonKey: _likeKey,
      onLike: _likeFromDoubleTap,
      onLanded: () => _bump.forward(from: 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          KeyedSubtree(key: _mediaKey, child: PostMedia(post: widget.post)),
          Row(
            children: [
              ScaleTransition(
                scale: _bumpScale,
                child: IconButton(
                  key: _likeKey,
                  icon: Icon(liked ? Icons.favorite : Icons.favorite_border),
                  onPressed: () => widget.onLikeChanged(!liked),
                ),
              ),
              // comment, share, save buttons...
            ],
          ),
        ],
      ),
    );
  }
}
```

5. **Run the Testing checklist** below on a real device.

## Testing checklist

- [ ] The heart lands exactly on the like button. A miss points to the coordinate conversion in \_likeButtonCenter, or a likeButtonKey on the wrong widget.
- [ ] Ripples and the heart's shadow have soft edges. Hard edges mean the `rive` package is too old.
- [ ] Smooth on a low-end Android phone, including several quick double taps in a row.
- [ ] Still lands correctly after scrolling the feed.
- [ ] Off-screen like button: no animation, the post is still liked.
- [ ] Reduce motion on: no animation, the post is liked and the button bumps.

## Known limitations

- **Rendering cost:** the heart uses feathering and clipping, which cost more to draw than a flat icon. Watch frame times on low-end devices.
- **Runtime support:** the file needs a recent `rive` Flutter runtime; older runtimes ignore feathering or data converters.
- **Overlay bounds:** positions are logical pixels relative to the overlay, so the overlay must cover both the tap area and the like button.
- **Verification:** the animation was verified in Rive's renderer; on-device Flutter testing is covered by the checklist above.

## Changelog

| Date | Version | Change |
| --- | --- | --- |
| 2026-11-17 | 1.0 | Initial release: double-tap ripple and heart flight to the like button |
